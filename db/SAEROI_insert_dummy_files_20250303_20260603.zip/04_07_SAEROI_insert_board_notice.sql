/*
    프로젝트 : 3차 프로젝트(saeroi) - EV용 배터리 절연가스켓 제조 MES
    목적     : 시연용 더미데이터 INSERT
    기준     : 2026-03-03 ~ 2026-06-03 / 전년도 비교 2025-03-03 ~ 2025-06-03
    달력     : 기본적으로 평일 기준, 주말 및 한국 공휴일/회사휴무 제외
    예외     : 2026-06-03은 실제 선거일 공휴일이지만 시연 기준일 KPI 공백 방지를 위해 포함
               전년도 같은 날짜 비교를 위해 2025-06-03도 비교용 예외 포함
    주의     : CREATE 실행 후 아래 실행순서에 맞춰 파일을 실행한다.
               DBeaver Oracle SQL Editor에서 파일 단위로 실행하는 것을 권장한다.
*/
SET DEFINE OFF;

-- ========================================================================
-- 04_07 공지사항 / 게시판 / 댓글 / 첨부파일 INSERT
-- ========================================================================

-- ========================================================================
-- 1. 공지사항(notice) - 시스템 관리 화면용
-- 대상 테이블: notice
-- INSERT 건수: 10건
-- ========================================================================
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (1, '6월 시연 전 생산실적 등록 기준 안내', '6월 시연 전 생산실적 등록 기준 안내에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 28, DATE '2026-05-21', DATE '2026-05-21', '게시', 'Y', '공지번호=NTC-20260521-0001');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (2, 'LOT 바코드 스캔 오류 발생 시 처리 절차', 'LOT 바코드 스캔 오류 발생 시 처리 절차에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 31, DATE '2026-05-22', DATE '2026-05-22', '게시', 'Y', '공지번호=NTC-20260522-0002');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (3, '자재입고 LOT 자동생성 확인 요청', '자재입고 LOT 자동생성 확인 요청에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 34, DATE '2026-05-23', DATE '2026-05-23', '게시', 'Y', '공지번호=NTC-20260523-0003');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (4, '검사관리 불량등록 기준 공지', '검사관리 불량등록 기준 공지에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 37, DATE '2026-05-24', DATE '2026-05-24', '게시', 'Y', '공지번호=NTC-20260524-0004');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (5, '라인별 설비점검 일정 안내', '라인별 설비점검 일정 안내에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 40, DATE '2026-05-25', DATE '2026-05-25', '게시', 'Y', '공지번호=NTC-20260525-0005');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (6, '재고조회 검색조건 사용 안내', '재고조회 검색조건 사용 안내에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 43, DATE '2026-05-26', DATE '2026-05-26', '게시', 'Y', '공지번호=NTC-20260526-0006');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (7, '작업지시 생성 시 완제품 LOT 확인', '작업지시 생성 시 완제품 LOT 확인에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 46, DATE '2026-05-27', DATE '2026-05-27', '게시', 'Y', '공지번호=NTC-20260527-0007');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (8, '대시보드 KPI 산식 검토 완료', '대시보드 KPI 산식 검토 완료에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 49, DATE '2026-05-28', DATE '2026-05-28', '게시', 'Y', '공지번호=NTC-20260528-0008');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (9, '공정진행 현황 조회 기준 안내', '공정진행 현황 조회 기준 안내에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 52, DATE '2026-05-29', DATE '2026-05-29', '게시', 'Y', '공지번호=NTC-20260529-0009');
INSERT INTO "notice" ("notice_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (10, '시연일 데이터 점검 체크리스트', '시연일 데이터 점검 체크리스트에 대한 상세 안내입니다. 3차 프로젝트 EV용 배터리 절연가스켓 제조 MES 시연 기준으로 작성되었습니다.', 1, 55, DATE '2026-05-30', DATE '2026-05-30', '게시', 'Y', '공지번호=NTC-20260530-0010');

-- ========================================================================
-- 2. 게시판(board) - 팀 공유/업무 게시글
-- 대상 테이블: board
-- INSERT 건수: 10건
-- ========================================================================
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (1, '생산실적 등록 화면 개선 의견', '생산실적 등록 화면 개선 의견 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 3, 12, DATE '2026-05-19', DATE '2026-05-19', '게시', '게시글번호=BRD-20260519-0001', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (2, '공정진행 현황 LOT 추적 표시 요청', '공정진행 현황 LOT 추적 표시 요청 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 4, 14, DATE '2026-05-20', DATE '2026-05-20', '게시', '게시글번호=BRD-20260520-0002', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (3, '재고조회 품목/창고 검색 테스트', '재고조회 품목/창고 검색 테스트 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 5, 16, DATE '2026-05-21', DATE '2026-05-21', '게시', '게시글번호=BRD-20260521-0003', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (4, '검사관리 불량유형 입력 확인', '검사관리 불량유형 입력 확인 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 2, 18, DATE '2026-05-22', DATE '2026-05-22', '게시', '게시글번호=BRD-20260522-0004', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (5, '작업지시 LOT 바코드 출력 테스트', '작업지시 LOT 바코드 출력 테스트 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 3, 20, DATE '2026-05-23', DATE '2026-05-23', '게시', '게시글번호=BRD-20260523-0005', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (6, 'BOM 기준 투입자재 확인 요청', 'BOM 기준 투입자재 확인 요청 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 4, 22, DATE '2026-05-24', DATE '2026-05-24', '게시', '게시글번호=BRD-20260524-0006', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (7, '라인별 생산량 리포트 검증', '라인별 생산량 리포트 검증 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 5, 24, DATE '2026-05-25', DATE '2026-05-25', '게시', '게시글번호=BRD-20260525-0007', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (8, 'OEE 설비가동이력 입력 확인', 'OEE 설비가동이력 입력 확인 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 2, 26, DATE '2026-05-26', DATE '2026-05-26', '게시', '게시글번호=BRD-20260526-0008', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (9, '원가편차율 대시보드 점검', '원가편차율 대시보드 점검 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 3, 28, DATE '2026-05-27', DATE '2026-05-27', '게시', '게시글번호=BRD-20260527-0009', 'Y');
INSERT INTO "board" ("board_id", "title", "content", "emp_id", "view_count", "created_date", "updated_date", "status", "remark", "use_yn") VALUES (10, '최종 시연 리허설 피드백', '최종 시연 리허설 피드백 관련 팀 내부 공유 내용입니다. 화면 시연과 DB 조회 기준을 함께 확인합니다.', 4, 30, DATE '2026-05-28', DATE '2026-05-28', '게시', '게시글번호=BRD-20260528-0010', 'Y');

-- ========================================================================
-- 3. 댓글(comment) - 게시글 댓글/대댓글
-- 대상 테이블: comment
-- INSERT 건수: 20건
-- ========================================================================
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (1, 1, NULL, 7, '확인했습니다. 1번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-23', DATE '2026-05-23', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (2, 1, 1, 3, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-23', DATE '2026-05-23', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (3, 2, NULL, 8, '확인했습니다. 2번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-24', DATE '2026-05-24', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (4, 2, 3, 4, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-24', DATE '2026-05-24', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (5, 3, NULL, 9, '확인했습니다. 3번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-25', DATE '2026-05-25', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (6, 3, 5, 2, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-25', DATE '2026-05-25', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (7, 4, NULL, 6, '확인했습니다. 4번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-26', DATE '2026-05-26', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (8, 4, 7, 3, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-26', DATE '2026-05-26', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (9, 5, NULL, 7, '확인했습니다. 5번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-27', DATE '2026-05-27', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (10, 5, 9, 4, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-27', DATE '2026-05-27', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (11, 6, NULL, 8, '확인했습니다. 6번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-28', DATE '2026-05-28', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (12, 6, 11, 2, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-28', DATE '2026-05-28', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (13, 7, NULL, 9, '확인했습니다. 7번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-29', DATE '2026-05-29', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (14, 7, 13, 3, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-29', DATE '2026-05-29', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (15, 8, NULL, 6, '확인했습니다. 8번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-22', DATE '2026-05-22', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (16, 8, 15, 4, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-22', DATE '2026-05-22', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (17, 9, NULL, 7, '확인했습니다. 9번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-23', DATE '2026-05-23', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (18, 9, 17, 2, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-23', DATE '2026-05-23', '게시', 'Y', '대댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (19, 10, NULL, 8, '확인했습니다. 10번 게시글 기준으로 화면/데이터를 점검하겠습니다.', DATE '2026-05-24', DATE '2026-05-24', '게시', 'Y', '1차 댓글');
INSERT INTO "comment" ("comment_id", "board_id", "parent_comment_id", "emp_id", "content", "created_date", "updated_date", "status", "use_yn", "remark") VALUES (20, 10, 19, 3, '관련 내용은 시연 전까지 반영 여부를 다시 확인하겠습니다.', DATE '2026-05-24', DATE '2026-05-24', '게시', 'Y', '대댓글');

-- ========================================================================
-- 4. 첨부파일(file) - 공지사항/게시글 첨부
-- 대상 테이블: file
-- INSERT 건수: 8건
-- ========================================================================
INSERT INTO "file" ("file_id", "notice_id", "board_id", "title", "saved_title", "file_path", "file_size", "created_date", "updated_date") VALUES (1, 1, NULL, 'notice_attach_1.pdf', 'notice_attach_1_1.pdf', '/upload/notice/202606/1/', 104448, DATE '2026-05-26', DATE '2026-05-26');
INSERT INTO "file" ("file_id", "notice_id", "board_id", "title", "saved_title", "file_path", "file_size", "created_date", "updated_date") VALUES (2, 2, NULL, 'notice_attach_2.pdf', 'notice_attach_2_2.pdf', '/upload/notice/202606/2/', 106496, DATE '2026-05-27', DATE '2026-05-27');
INSERT INTO "file" ("file_id", "notice_id", "board_id", "title", "saved_title", "file_path", "file_size", "created_date", "updated_date") VALUES (3, 3, NULL, 'notice_attach_3.pdf', 'notice_attach_3_3.pdf', '/upload/notice/202606/3/', 108544, DATE '2026-05-28', DATE '2026-05-28');
INSERT INTO "file" ("file_id", "notice_id", "board_id", "title", "saved_title", "file_path", "file_size", "created_date", "updated_date") VALUES (4, 4, NULL, 'notice_attach_4.pdf', 'notice_attach_4_4.pdf', '/upload/notice/202606/4/', 110592, DATE '2026-05-29', DATE '2026-05-29');
INSERT INTO "file" ("file_id", "notice_id", "board_id", "title", "saved_title", "file_path", "file_size", "created_date", "updated_date") VALUES (5, NULL, 1, 'board_attach_1.xlsx', 'board_attach_1_5.xlsx', '/upload/board/202606/5/', 208896, DATE '2026-05-25', DATE '2026-05-25');
INSERT INTO "file" ("file_id", "notice_id", "board_id", "title", "saved_title", "file_path", "file_size", "created_date", "updated_date") VALUES (6, NULL, 2, 'board_attach_2.xlsx', 'board_attach_2_6.xlsx', '/upload/board/202606/6/', 212992, DATE '2026-05-26', DATE '2026-05-26');
INSERT INTO "file" ("file_id", "notice_id", "board_id", "title", "saved_title", "file_path", "file_size", "created_date", "updated_date") VALUES (7, NULL, 3, 'board_attach_3.xlsx', 'board_attach_3_7.xlsx', '/upload/board/202606/7/', 217088, DATE '2026-05-27', DATE '2026-05-27');
INSERT INTO "file" ("file_id", "notice_id", "board_id", "title", "saved_title", "file_path", "file_size", "created_date", "updated_date") VALUES (8, NULL, 4, 'board_attach_4.xlsx', 'board_attach_4_8.xlsx', '/upload/board/202606/8/', 221184, DATE '2026-05-28', DATE '2026-05-28');

COMMIT;

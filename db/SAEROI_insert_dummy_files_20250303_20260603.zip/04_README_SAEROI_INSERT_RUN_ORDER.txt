3차 프로젝트(saeroi) INSERT 파일 실행 순서
============================================================

기준
- 프로젝트: EV용 배터리 절연가스켓 제조 MES
- 시연 기준일: 2026-06-03
- 시연용 기간: 2026-03-03 ~ 2026-06-03
- 전년도 비교 기간: 2025-03-03 ~ 2025-06-03
- 기본 달력: 평일 기준, 주말 및 한국 공휴일/회사휴무 제외
- 예외: 2026-06-03은 실제 선거일 공휴일이지만 시연 기준일 KPI가 0으로 보이지 않도록 포함
        전년도 같은 날짜 비교를 위해 2025-06-03도 포함

실행 전
1. 01_SAEROI_create_short_constraints.sql 실행
2. 기존 데이터가 있으면 03_SAEROI_delete.sql 실행
3. 아래 INSERT 파일을 순서대로 실행
4. 05_SAEROI_select.sql로 건수/KPI/LOT 추적 조회 확인

실행 순서
1. 04_00_SAEROI_insert_master.sql
2. 04_01_SAEROI_insert_bom_process.sql
3. 04_02_SAEROI_insert_plan_order.sql
4. 04_03_SAEROI_insert_material_inout.sql
5. 04_04_SAEROI_insert_production_inspection_defect.sql
6. 04_05_SAEROI_insert_inventory_product_inout.sql
7. 04_06_SAEROI_insert_equipment_cost.sql
8. 04_07_SAEROI_insert_board_notice.sql

생성 규모
- 2025년 입력 대상 영업일: 63일
- 2026년 입력 대상 영업일: 64일
- 2026년 작업지시: 하루 8~12건 기준
- 2025년 작업지시: 하루 4~8건 기준

테이블별 INSERT 건수
- client: 9건
- line: 4건
- emp: 12건
- item: 16건
- equipment: 16건
- defect: 8건
- bom: 6건
- bom_detail: 36건
- process: 36건
- process_detail: 36건
- standard_cost: 6건
- production_plan: 571건
- work_order: 1009건
- material_inout: 7156건
- production: 1009건
- inspection: 1009건
- defect_list: 390건
- inventory: 22건
- product_inout: 1009건
- equipment_history: 2032건
- actual_cost_daily: 762건
- notice: 10건
- board: 10건
- comment: 20건
- file: 8건

주의사항
- 현재 DB에 문서번호 전용 컬럼이 없으므로 PP/WO/PR/INSP/DEF/MI/MO/FG-MI 번호는 remark에 기록했다.
- 완제품 LOT는 work_order.product_lot에 FGLOT-yyyymmdd-순번 형식으로 들어간다.
- 자재 LOT는 material_inout.material_lot에 RMLOT-yyyymmdd-순번 형식으로 들어간다.
- 재고조회는 LOT별 현재고가 아니라 품목별/창고별 현재고 기준이며, 재고상태 코드는 inventory.remark에 기록했다.
- 각 파일 마지막에 COMMIT이 포함되어 있다.

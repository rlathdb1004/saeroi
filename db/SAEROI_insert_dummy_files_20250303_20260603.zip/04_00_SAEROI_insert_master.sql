/*
    프로젝트 : 3차 프로젝트(saeroi) - EV용 배터리 절연가스켓 제조 MES
    목적     : 시연용 더미데이터 INSERT
    기준     : 2026-03-03 ~ 2026-06-03 / 전년도 비교 2025-03-03 ~ 2025-06-03
    달력     : 기본적으로 평일 기준, 주말 및 한국 공휴일/회사휴무 제외
    예외     : 2026-06-03은 실제 선거일 공휴일이지만 시연 기준일 KPI 공백 방지를 위해 포함
               전년도 같은 날짜 비교를 위해 2025-06-03도 비교용 예외 포함
    주의     : CREATE 실행 후 아래 실행순서에 맞춰 파일을 실행한다.
               DBeaver Oracle SQL Editor에서 파일 단위로 실행하는 것을 권장한다.
*/
SET DEFINE OFF;

-- ========================================================================
-- 04_00 기준정보 INSERT
-- ========================================================================

-- ========================================================================
-- 1. 거래처 마스터(client) - 공급처/납품처/설비업체
-- 대상 테이블: client
-- INSERT 건수: 9건
-- ========================================================================
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (1, 'BP-SUP-001', '에코폴리머소재', 'SUPPLIER', '충남 아산시 둔포면 소재산단1로 10', '김소재', '041-100-1001', '영업1팀', 'EPDM Foam 원자재 공급처', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (2, 'BP-SUP-002', '코리아실리콘텍', 'SUPPLIER', '경기 화성시 실리콘로 22', '이실리', '031-200-2002', '소재영업팀', 'Silicone Foam 원자재 공급처', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (3, 'BP-SUP-003', '하이퍼PU소재', 'SUPPLIER', '충북 진천군 산업단지로 33', '박피유', '043-300-3003', '영업팀', 'PU Foam 원자재 공급처', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (4, 'BP-SUP-004', '신성접착필름', 'SUPPLIER', '충남 천안시 필름로 44', '최필름', '041-400-4004', '기술영업팀', '접착필름 및 이형필름 공급처', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (5, 'BP-SUP-005', '대한포장자재', 'SUPPLIER', '경기 평택시 포장로 55', '정포장', '031-500-5005', '영업팀', '박스/라벨/포장재 공급처', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (6, 'BP-CUS-001', '현대자동차 배터리팩사업부', 'CUSTOMER', '울산광역시 북구 염포로 700', '한납품', '052-600-6006', '구매팀', '아이오닉5 배터리팩 가스켓 납품처', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (7, 'BP-CUS-002', '기아 오토랜드 화성', 'CUSTOMER', '경기 화성시 우정읍 기아자동차로 95', '오납품', '031-700-7007', '구매팀', 'EV6 배터리팩 가스켓 납품처', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (8, 'BP-CUS-003', '현대모비스 전동화부품', 'CUSTOMER', '충북 충주시 대소원면 기업도시로 20', '모비스', '043-800-8008', '품질구매팀', '전동화 부품 협력 고객사', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "client" ("client_id", "client_code", "client_name", "client_type", "client_adress", "client_man", "client_tel", "client_dept", "remark", "created_date", "updated_date", "use_yn") VALUES (9, 'BP-SUP-006', '정밀설비서비스', 'SUPPLIER', '충남 아산시 설비로 66', '장설비', '041-900-9009', 'A/S팀', '설비 정비 및 부품 공급처', DATE '2026-03-01', DATE '2026-03-01', 'Y');

-- ========================================================================
-- 2. 라인 마스터(line) - 4개 생산라인
-- 대상 테이블: line
-- INSERT 건수: 4건
-- ========================================================================
INSERT INTO "line" ("line_id", "line_code", "line_name", "line_status", "created_date", "updated_date", "remark") VALUES (1, 'LINE-001', '1라인(EPDM 계열 가스켓 주 생산 라인)', 'LINE-RUN', DATE '2026-03-01', DATE '2026-03-01', 'EPDM Foam 계열 제품을 주로 생산');
INSERT INTO "line" ("line_id", "line_code", "line_name", "line_status", "created_date", "updated_date", "remark") VALUES (2, 'LINE-002', '2라인(Silicone 계열 가스켓 주 생산 라인)', 'LINE-RUN', DATE '2026-03-01', DATE '2026-03-01', 'Silicone Foam 계열 제품을 주로 생산');
INSERT INTO "line" ("line_id", "line_code", "line_name", "line_status", "created_date", "updated_date", "remark") VALUES (3, 'LINE-003', '3라인(PU 계열 가스켓 주 생산 라인)', 'LINE-RUN', DATE '2026-03-01', DATE '2026-03-01', 'PU Foam 계열 제품을 주로 생산');
INSERT INTO "line" ("line_id", "line_code", "line_name", "line_status", "created_date", "updated_date", "remark") VALUES (4, 'LINE-004', '4라인(혼합 생산 및 예비 생산 라인)', 'LINE-IDLE', DATE '2026-03-01', DATE '2026-03-01', '긴급오더 및 혼합 생산 대응');

-- ========================================================================
-- 3. 사용자/사원 마스터(emp) - 관리자/작업자/검사원/창고담당자
-- 대상 테이블: emp
-- INSERT 건수: 12건
-- ========================================================================
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (1, 'EMP-0001', '1234', '박민호', '생산관리팀', 'MES관리자', DATE '2024-01-02', '010-1111-0001', 'pmh@saeroi.local', '재직', 'ADMIN', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (2, 'EMP-0002', '1234', '이왕재', '생산관리팀', '생산관리자', DATE '2024-01-08', '010-1111-0002', 'lwj@saeroi.local', '재직', 'PROD_MANAGER', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (3, 'EMP-0003', '1234', '강정석', '품질관리팀', '품질관리자', DATE '2024-01-15', '010-1111-0003', 'kjs@saeroi.local', '재직', 'QC_MANAGER', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (4, 'EMP-0004', '1234', '이용상', '자재관리팀', '자재관리자', DATE '2024-01-22', '010-1111-0004', 'lys@saeroi.local', '재직', 'WH_MANAGER', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (5, 'EMP-0005', '1234', '강유빈', '설비관리팀', '설비관리자', DATE '2024-02-01', '010-1111-0005', 'kyb@saeroi.local', '재직', 'EQ_MANAGER', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (6, 'EMP-0101', '1234', '라인작업자1', '생산1반', '작업자', DATE '2024-02-05', '010-2222-0101', 'op101@saeroi.local', '재직', 'OPERATOR', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (7, 'EMP-0102', '1234', '라인작업자2', '생산1반', '작업자', DATE '2024-02-05', '010-2222-0102', 'op102@saeroi.local', '재직', 'OPERATOR', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (8, 'EMP-0103', '1234', '라인작업자3', '생산2반', '작업자', DATE '2024-02-07', '010-2222-0103', 'op103@saeroi.local', '재직', 'OPERATOR', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (9, 'EMP-0104', '1234', '라인작업자4', '생산2반', '작업자', DATE '2024-02-07', '010-2222-0104', 'op104@saeroi.local', '재직', 'OPERATOR', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (10, 'EMP-0201', '1234', '품질검사원1', '품질관리팀', '검사원', DATE '2024-03-01', '010-3333-0201', 'qc201@saeroi.local', '재직', 'QC_OPERATOR', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (11, 'EMP-0202', '1234', '품질검사원2', '품질관리팀', '검사원', DATE '2024-03-01', '010-3333-0202', 'qc202@saeroi.local', '재직', 'QC_OPERATOR', DATE '2026-03-01', DATE '2026-03-01');
INSERT INTO "emp" ("emp_id", "empno", "emp_pw", "ename", "dept", "job", "hire_date", "emp_tel", "email", "status", "role", "created_date", "updated_date") VALUES (12, 'EMP-0301', '1234', '창고담당자1', '자재관리팀', '창고담당', DATE '2024-03-11', '010-4444-0301', 'wh301@saeroi.local', '재직', 'WH_OPERATOR', DATE '2026-03-01', DATE '2026-03-01');

-- ========================================================================
-- 4. 품목 마스터(item) - 완제품 6종 + 원자재/부자재
-- 대상 테이블: item
-- INSERT 건수: 16건
-- ========================================================================
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (1001, NULL, 6, 'FG-GSK-ION5-EPDM-001', '아이오닉 5 배터리팩 메인 방수 가스켓(EPDM Foam)', 'FG', 1200, 'EA', 'ION5 EPDM 메인 방수 가스켓', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (1002, NULL, 6, 'FG-GSK-ION5-SIL-001', '아이오닉 5 배터리 커버 실리콘 가스켓(Silicone Foam)', 'FG', 1000, 'EA', 'ION5 실리콘 커버 가스켓', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (1003, NULL, 8, 'FG-GSK-ION5-PU-001', '아이오닉 5 배터리 서비스커버 PU 가스켓(PU Foam)', 'FG', 900, 'EA', 'ION5 PU 서비스커버 가스켓', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (1004, NULL, 7, 'FG-GSK-EV6-EPDM-001', 'EV6 배터리팩 메인 방수 가스켓(EPDM Foam)', 'FG', 1200, 'EA', 'EV6 EPDM 메인 방수 가스켓', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (1005, NULL, 7, 'FG-GSK-EV6-SIL-001', 'EV6 배터리 커버 실리콘 가스켓(Silicone Foam)', 'FG', 1000, 'EA', 'EV6 실리콘 커버 가스켓', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (1006, NULL, 7, 'FG-GSK-EV6-PU-001', 'EV6 배터리 모듈 보호 PU 가스켓(PU Foam)', 'FG', 900, 'EA', 'EV6 PU 모듈 보호 가스켓', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (2001, 1, NULL, 'RM-EPDM-SHEET-001', 'EPDM 발포시트 원단', 'RM', 30000, 'M', 'EPDM Foam 가스켓 타발용 원단', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (2002, 2, NULL, 'RM-SIL-SHEET-001', '실리콘 발포시트 원단', 'RM', 25000, 'M', 'Silicone Foam 가스켓 타발용 원단', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (2003, 3, NULL, 'RM-PU-SHEET-001', 'PU 발포시트 원단', 'RM', 25000, 'M', 'PU Foam 가스켓 타발용 원단', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (2004, 4, NULL, 'RM-ADH-FILM-001', '배터리팩용 내열 접착필름', 'RM', 20000, 'M', '라미네이션 공정용 접착필름', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (2005, 4, NULL, 'RM-RELEASE-FILM-001', '이형필름', 'RM', 18000, 'M', '접착면 보호용 이형필름', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (2006, 4, NULL, 'RM-PRIMER-LIQ-001', '프라이머액', 'RM', 500, 'KG', '접착력 보강용 프라이머액', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (3001, 5, NULL, 'SM-BOX-001', '완제품 포장박스', 'SM', 2000, 'EA', '완제품 포장용 박스', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (3002, 5, NULL, 'SM-LABEL-001', 'LOT 라벨', 'SM', 5000, 'EA', '제품 및 포장 LOT 라벨', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (3003, 5, NULL, 'SM-PALLET-001', '출하 파렛트', 'SM', 200, 'EA', '완제품 보관 및 출하용 파렛트', DATE '2026-03-01', DATE '2026-03-01', 'Y');
INSERT INTO "item" ("item_id", "supplier_id", "client_id", "item_code", "item_name", "item_type", "safety_stock", "item_unit", "remark", "created_date", "updated_date", "use_yn") VALUES (3004, 5, NULL, 'SM-BAG-001', '방습 포장백', 'SM', 3000, 'EA', '가스켓 습기 방지 포장백', DATE '2026-03-01', DATE '2026-03-01', 'Y');

-- ========================================================================
-- 5. 설비 마스터(equipment) - 라인별 주요 설비
-- 대상 테이블: equipment
-- INSERT 건수: 16건
-- ========================================================================
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (1, 1, 'EQ-CUT-001', '1라인 고속 타발기', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '가스켓 형상 타발', 9, 15700000, DATE '2024-02-16', '1라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (2, 1, 'EQ-LAM-001', '1라인 라미네이터', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '접착필름 라미네이션', 9, 16400000, DATE '2024-02-17', '1라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (3, 1, 'EQ-PRS-001', '1라인 열압착 프레스', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '치수 안정화 및 압착', 9, 17100000, DATE '2024-02-18', '1라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (4, 1, 'EQ-VIS-001', '1라인 비전검사기', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '외관/치수 자동검사', 9, 17800000, DATE '2024-02-19', '1라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (5, 2, 'EQ-CUT-002', '2라인 고속 타발기', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '가스켓 형상 타발', 9, 18500000, DATE '2024-02-20', '2라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (6, 2, 'EQ-LAM-002', '2라인 라미네이터', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '접착필름 라미네이션', 9, 19200000, DATE '2024-02-21', '2라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (7, 2, 'EQ-PRS-002', '2라인 열압착 프레스', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '치수 안정화 및 압착', 9, 19900000, DATE '2024-02-22', '2라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (8, 2, 'EQ-VIS-002', '2라인 비전검사기', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '외관/치수 자동검사', 9, 20600000, DATE '2024-02-23', '2라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (9, 3, 'EQ-CUT-003', '3라인 고속 타발기', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '가스켓 형상 타발', 9, 21300000, DATE '2024-02-24', '3라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (10, 3, 'EQ-LAM-003', '3라인 라미네이터', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '접착필름 라미네이션', 9, 22000000, DATE '2024-02-25', '3라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (11, 3, 'EQ-PRS-003', '3라인 열압착 프레스', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '치수 안정화 및 압착', 9, 22700000, DATE '2024-02-26', '3라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (12, 3, 'EQ-VIS-003', '3라인 비전검사기', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '외관/치수 자동검사', 9, 23400000, DATE '2024-02-27', '3라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (13, 4, 'EQ-CUT-004', '4라인 고속 타발기', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '가스켓 형상 타발', 9, 24100000, DATE '2024-02-28', '4라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (14, 4, 'EQ-LAM-004', '4라인 라미네이터', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '접착필름 라미네이션', 9, 24800000, DATE '2024-02-29', '4라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (15, 4, 'EQ-PRS-004', '4라인 열압착 프레스', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '치수 안정화 및 압착', 9, 25500000, DATE '2024-03-01', '4라인 설비구역');
INSERT INTO "equipment" ("equip_id", "line_id", "equip_code", "equip_name", "equip_status", "created_date", "updated_date", "use_yn", "remark", "client_id", "equip_price", "buy_date", "equip_loc") VALUES (16, 4, 'EQ-VIS-004', '4라인 비전검사기', 'EQ-RUN', DATE '2024-02-01', DATE '2026-03-01', 'Y', '외관/치수 자동검사', 9, 26200000, DATE '2024-03-02', '4라인 설비구역');

-- ========================================================================
-- 6. 불량코드 마스터(defect) - 검사관리/불량관리 기준정보
-- 대상 테이블: defect
-- INSERT 건수: 8건
-- ========================================================================
INSERT INTO "defect" ("defect_id", "defect_code", "defect_type", "defect_name", "created_date", "updated_date", "remark") VALUES (1, 'DEF-DIM', 'QUALITY', '치수불량', DATE '2026-03-01', DATE '2026-03-01', '규격 외 치수 편차');
INSERT INTO "defect" ("defect_id", "defect_code", "defect_type", "defect_name", "created_date", "updated_date", "remark") VALUES (2, 'DEF-BURR', 'QUALITY', '버 발생', DATE '2026-03-01', DATE '2026-03-01', '타발면 버 및 모서리 미세 돌기');
INSERT INTO "defect" ("defect_id", "defect_code", "defect_type", "defect_name", "created_date", "updated_date", "remark") VALUES (3, 'DEF-ADH', 'QUALITY', '접착불량', DATE '2026-03-01', DATE '2026-03-01', '접착필름 들뜸/박리');
INSERT INTO "defect" ("defect_id", "defect_code", "defect_type", "defect_name", "created_date", "updated_date", "remark") VALUES (4, 'DEF-CONTAM', 'QUALITY', '오염', DATE '2026-03-01', DATE '2026-03-01', '표면 이물/분진/오일 오염');
INSERT INTO "defect" ("defect_id", "defect_code", "defect_type", "defect_name", "created_date", "updated_date", "remark") VALUES (5, 'DEF-TEAR', 'QUALITY', '찢김', DATE '2026-03-01', DATE '2026-03-01', '원단 또는 완제품 찢김');
INSERT INTO "defect" ("defect_id", "defect_code", "defect_type", "defect_name", "created_date", "updated_date", "remark") VALUES (6, 'DEF-THICK', 'QUALITY', '두께불량', DATE '2026-03-01', DATE '2026-03-01', '두께 기준 초과/미달');
INSERT INTO "defect" ("defect_id", "defect_code", "defect_type", "defect_name", "created_date", "updated_date", "remark") VALUES (7, 'DEF-LABEL', 'PACKING', '라벨불량', DATE '2026-03-01', DATE '2026-03-01', 'LOT 라벨 누락/오부착');
INSERT INTO "defect" ("defect_id", "defect_code", "defect_type", "defect_name", "created_date", "updated_date", "remark") VALUES (8, 'DEF-APPEAR', 'QUALITY', '외관불량', DATE '2026-03-01', DATE '2026-03-01', '눌림, 찍힘, 색상 차이');

COMMIT;
